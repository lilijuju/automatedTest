import requests

res_dict = requests.post()